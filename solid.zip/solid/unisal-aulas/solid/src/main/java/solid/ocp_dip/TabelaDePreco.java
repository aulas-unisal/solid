package solid.ocp_dip;

public interface TabelaDePreco {
	double descontoPara(double valor);
}
