package solid.encapsulamento;

public enum MeioDePagamento {
	BOLETO;
}
