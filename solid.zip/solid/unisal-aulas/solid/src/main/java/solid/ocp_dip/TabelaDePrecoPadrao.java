package solid.ocp_dip;

public class TabelaDePrecoPadrao implements TabelaDePreco{

	public double descontoPara(double valor) {
		return 0;
	}
	
}
