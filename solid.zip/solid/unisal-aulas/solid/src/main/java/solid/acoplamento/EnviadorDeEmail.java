package solid.acoplamento;

public class EnviadorDeEmail implements AcaoAposGerarNota{

	public void executa(NotaFiscal nf) {
		System.out.println("Enviando email.");
	}

}
