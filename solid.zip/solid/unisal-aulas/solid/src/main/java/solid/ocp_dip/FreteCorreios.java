package solid.ocp_dip;

public class FreteCorreios implements ServicoDeEntrega{

	public double para(String cidade) {
		return 0;
	}

}
