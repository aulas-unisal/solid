package solid.coesao;

public interface RegraDeCalculo {
	public double calcula(Funcionario funcionario);
}
