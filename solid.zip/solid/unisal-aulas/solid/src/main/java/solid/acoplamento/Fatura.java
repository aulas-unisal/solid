package solid.acoplamento;

public class Fatura {
	private double valorMensal;

	public Fatura() {
	}

	public double getValorMensal() {
		return valorMensal;
	}

	public void setValorMensal(double valorMensal) {
		this.valorMensal = valorMensal;
	}
	
}
