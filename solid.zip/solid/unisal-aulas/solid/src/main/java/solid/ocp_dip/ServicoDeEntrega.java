package solid.ocp_dip;

public interface ServicoDeEntrega {
	double para(String cidade);
}
