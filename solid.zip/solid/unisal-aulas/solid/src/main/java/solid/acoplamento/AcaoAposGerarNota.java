package solid.acoplamento;

public interface AcaoAposGerarNota {
	public void executa(NotaFiscal nf);
}
